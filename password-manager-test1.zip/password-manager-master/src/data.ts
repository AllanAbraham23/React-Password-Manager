export const data = [
    {
        service: 'google.com',
        login: 'johndoe@gmail.com',
        password: 'abcd'
    },
    {
        service: 'facebook.com',
        login: 'janedoe@gmail.com',
        password: '0987654321'
    },
    {
        service: 'twitter.com',
        login: 'johndoe@gmail.com',
        password: '1234567890'
    }
]